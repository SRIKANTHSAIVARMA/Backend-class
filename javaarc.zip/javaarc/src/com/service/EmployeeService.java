package com.service;

import java.util.Map.Entry;
import java.util.Set;

import com.dao.EmployeeDao;
import com.dao.EmployeeDaoInf;
import com.model.Employee;

public class EmployeeService implements EmployeeServiceInf {

	EmployeeDaoInf dao=new EmployeeDao();
	@Override
	public int addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return dao.addEmployee(emp);
	}

	@Override
	public Employee updateEmployee(int empid, Employee emp) {
		// TODO Auto-generated method stub
		return dao.updateEmployee(empid, emp);
	}

	@Override
	public Employee getEmployee(int empid) {
		// TODO Auto-generated method stub
		return dao.getEmployee(empid);
	}

	@Override
	public String deleteEmployee(int empid) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(empid);
	}

	@Override
	public Set<Entry<Integer, Employee>> getallEmployees() {
		// TODO Auto-generated method stub
		return dao.getallEmployees();
	}

	
}
