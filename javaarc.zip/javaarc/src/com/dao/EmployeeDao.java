package com.dao;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.model.Employee;

public class EmployeeDao implements EmployeeDaoInf {

	HashMap<Integer, Employee> hasMap=new HashMap<Integer, Employee>();//database
	int empid=200;
	@Override
	public int addEmployee(Employee emp) {
		hasMap.put(++empid, emp);
		return empid ;
	}

	@Override
	public Employee updateEmployee(int empid, Employee emp) {
		Employee empobj=hasMap.put(empid, emp);
		return empobj;
	}

	@Override
	public Employee getEmployee(int empid) {
		Employee em=hasMap.get(empid);
		return em;
	}

	@Override
	public String deleteEmployee(int empid) {
	Employee er=hasMap.remove(empid);
		return "employee del" +empid;
	}

	@Override
	public Set<Entry<Integer, Employee>> getallEmployees() {
		Set <Entry <Integer, Employee>> itr =hasMap.entrySet();
		return itr;
	}

}
