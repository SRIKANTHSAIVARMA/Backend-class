package com.hotel.management;

public class HotelMain {
	public static void main(String[] args) {
		DeluxRoom dr = new DeluxRoom(123, "345A", 6789.67,6789.98);
		StandardRoom sr = new StandardRoom(234, "122D", 230, true);
		Customer cs = new Customer(004, "srikanth", "1234567890", sr);
		cs.rentRoom();
		cs.show();
	}
}
