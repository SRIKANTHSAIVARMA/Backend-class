package com.hotel.management;

public abstract class Person {
	int id;
	String name;
	String phnNum;
	//Parameterized constructor
	public Person (int id,String name,String phnNum)
	{
		this.id=id;
		this.name=name;
		this.phnNum=phnNum;		
	}

//abstract method for implementation
public abstract void show();

}